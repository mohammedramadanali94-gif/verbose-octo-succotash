# 🚀 دليل النشر على Vercel (موصى به)

Vercel هي المنصة الأفضل لنشر تطبيقات Next.js لأنها مبنية من قبل نفس فريق Next.js.

## 📋 الخطوات:

### 1. إعداد المستودع على GitHub
```bash
git init
git add .
git commit -m "Ready for Vercel deployment"
git branch -M main
git remote add origin https://github.com/yourusername/calculator-app.git
git push -u origin main
```

### 2. النشر على Vercel
1. اذهب إلى [vercel.com](https://vercel.com)
2. سجل الدخول بحساب GitHub
3. اضغط "New Project"
4. اختر مستودع `calculator-app`
5. أضف متغيرات البيئة:
   ```
   NEXT_PUBLIC_SUPABASE_URL = https://uwvfifumomhzroeqvhxa.supabase.co
   NEXT_PUBLIC_SUPABASE_ANON_KEY = eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...
   ```

### 3. النشر التلقائي
- Vercel سينشر التطبيق تلقائياً
- ستحصل على رابط مثل: `https://calculator-app.vercel.app`
- كل دفعة إلى GitHub ستنشر تلقائياً

## ✨ المميزات:
- 🚀 نشر فوري
- 🔄 CI/CD تلقائي
- 🌐 CDN عالمي
- 🔒 SSL مجاني
- 📊 Analytics مجاني

## 🔧 إعدادات إضافية:
في `vercel.json` تم إعداد:
- Security headers
- Environment variables
- Build optimization