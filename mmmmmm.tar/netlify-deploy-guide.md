# 🚀 دليل النشر على Netlify

Netlify خيار جيد للنشر مع دعم جيد لتطبيقات JavaScript.

## 📋 الخطوات:

### 1. تعديل إعدادات البناء
أضف هذا الملف `netlify.toml`:

```toml
[build]
  command = "npm run build"
  publish = ".next"

[build.environment]
  NODE_VERSION = "18"

[[redirects]]
  from = "/*"
  to = "/index.html"
  status = 200
```

### 2. النشر على Netlify
1. اذهب إلى [netlify.com](https://netlify.com)
2. سجل الدخول بحساب GitHub
3. اختر المستودع
4. إعدادات البناء:
   - Build command: `npm run build`
   - Publish directory: `.next`
5. أضف متغيرات البيئة في Environment variables

## ⚠️ ملاحظات:
- Netlify قد لا يكون مثالياً لتطبيقات Next.js المعقدة
- Vercel يبقى الخيار الأفضل