# 📦 دليل التصدير الثابت للـ GitHub Pages

إذا كنت مصراً على استخدام GitHub Pages، يمكننا تحويل التطبيق إلى نسخة ثابتة.

## ⚠️ تحذير مهم:
النسخة الثابتة ستفقد:
- ❌ نظام المصادقة (Supabase Auth)
- ❌ API routes
- ❌ Server-side rendering
- ❌ Environment variables الحقيقية

## 🔄 التعديلات المطلوبة:

### 1. تعديل next.config.ts
```typescript
const nextConfig: NextConfig = {
  // ... existing config
  output: 'export',
  trailingSlash: true,
  images: {
    unoptimized: true
  }
}
```

### 2. تعديل صفحة تسجيل الدخول
ستصبح صفحة عرض فقط بدون وظائف حقيقية

### 3. إنشاء نسخة تجريبية
```bash
npm run build
npm run export
```

## 📋 الخطوات للنشر على GitHub Pages:

### 1. تفعيل GitHub Pages
1. اذهب إلى Settings > Pages في مستودعك
2. اختر "Deploy from a branch"
3. اختر `main` و `/root`

### 2. إضافة GitHub Actions
أنشئ ملف `.github/workflows/deploy.yml`:

```yaml
name: Deploy to GitHub Pages

on:
  push:
    branches: [ main ]

jobs:
  build-and-deploy:
    runs-on: ubuntu-latest
    steps:
    - uses: actions/checkout@v2
    - name: Setup Node.js
      uses: actions/setup-node@v2
      with:
        node-version: '18'
    - name: Install dependencies
      run: npm ci
    - name: Build
      run: npm run build
    - name: Export
      run: npm run export
    - name: Deploy to GitHub Pages
      uses: peaceiris/actions-gh-pages@v3
      with:
        github_token: ${{ secrets.GITHUB_TOKEN }}
        publish_dir: ./out
```

## 🎯 التوصية:
استخدم Vercel بدلاً من GitHub Pages للحصول على أفضل تجربة!