# 🧮 الآلة الحاسبة التفاعلية

تطبيق آلة حاسبة عربية حديثة مع نظام مصادقة مستخدمين متكامل وقاعدة بيانات Supabase.

## ✨ المميزات

### 🔐 نظام المصادقة
- تسجيل دخول آمن باستخدام البريد الإلكتروني وكلمة المرور
- إنشاء حساب جديد مع التحقق من البيانات
- جلسة مستخدم مستمرة وآمنة
- حماية الصفحات المتقدمة

### 🧮 الآلة الحاسبة
- عمليات حسابية أساسية (الجمع، الطرح، الضرب، القسمة)
- دعم الأرقام العربية
- واجهة مستخدم عصرية ومتجاوبة
- وظائف إضافية (النسبة المئوية، تغيير الإشارة، الفاصلة العشرية)

### 🛡️ الأمان
- حماية XSS و CSRF
- رؤوس أمان HTTP
- التحقق من صحة البيانات
- جلسات آمنة

## 🚀 التقنيات المستخدمة

- **Framework**: Next.js 15 مع App Router
- **Language**: TypeScript
- **Styling**: Tailwind CSS + shadcn/ui
- **Database**: Supabase (PostgreSQL)
- **Authentication**: Supabase Auth
- **Deployment**: Docker, Vercel

## 📋 المتطلبات

- Node.js 18 أو أحدث
- npm أو yarn
- حساب Supabase

## 🛠️ التثبيت والتشغيل

### 1. استنساخ المشروع

```bash
git clone <repository-url>
cd calculator-app
```

### 2. تثبيت الاعتماديات

```bash
npm install
```

### 3. إعداد متغيرات البيئة

انسخ ملف `.env.example` إلى `.env.local`:

```bash
cp .env.example .env.local
```

عدل الملف وأضف بيانات Supabase الخاصة بك:

```env
NEXT_PUBLIC_SUPABASE_URL=https://your-project.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY=your-anon-key-here
SUPABASE_SERVICE_ROLE_KEY=your-service-role-key-here
NEXTAUTH_URL=http://localhost:3000
NEXTAUTH_SECRET=your-secret-key-here
```

### 4. تشغيل التطبيق

```bash
npm run dev
```

افتح المتصفح على `http://localhost:3000`

## 🚀 النشر

### النشر على Vercel (موصى به)

1. ادفع الكود إلى GitHub
2. ربط المستودع بـ Vercel
3. أضف متغيرات البيئة في Vercel Dashboard
4. انشر التطبيق

### النشر باستخدام Docker

1. بناء الصورة:

```bash
docker build -t calculator-app .
```

2. تشغيل الحاوية:

```bash
docker run -p 3000:3000 calculator-app
```

### استخدام Docker Compose

```bash
docker-compose up -d
```

## 📁 هيكل المشروع

```
src/
├── app/
│   ├── page.tsx              # صفحة تسجيل الدخول
│   ├── register/
│   │   └── page.tsx          # صفحة إنشاء حساب
│   ├── calculator/
│   │   └── page.tsx          # صفحة الحاسبة المحمية
│   └── layout.tsx            # التخطيط الرئيسي
├── components/
│   └── ui/                   # مكونات shadcn/ui
├── lib/
│   └── supabase.ts           # إعدادات Supabase
└── globals.css               # الأنماط العامة
```

## 🔧 إعدادات Supabase

1. أنشئ مشروع جديد في [Supabase](https://supabase.com)
2. فعل Email/Password authentication
3. احصل على URL و API Keys من Settings > API
4. أضفها إلى متغيرات البيئة

## 🛡️ الأمان

- التحقق من صحة المدخلات
- حماية ضد XSS
- رؤوس أمان HTTP
- جلسات آمنة
- متغيرات البيئة المحمية

## 📱 التوافق

- ✅ Chrome 90+
- ✅ Firefox 88+
- ✅ Safari 14+
- ✅ Edge 90+
- ✅ Mobile Responsive

## 🤝 المساهمة

1. Fork المشروع
2. أنشئ فرعًا جديدًا (`git checkout -b feature/AmazingFeature`)
3. ادفع التغييرات (`git commit -m 'Add some AmazingFeature'`)
4. ادفع الفرع (`git push origin feature/AmazingFeature`)
5. افتح Pull Request

## 📄 الرخصة

هذا المشروع مرخص تحت رخصة MIT - انظر ملف [LICENSE](LICENSE) للتفاصيل.

## 🆘 الدعم

إذا واجهت أي مشاكل، يرجى فتح Issue في GitHub.

---

**مصنوع بـ ❤️ باستخدام Next.js و Supabase**