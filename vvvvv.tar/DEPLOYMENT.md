# 📚 دليل النشر

هذا الدليل يشرح كيفية نشر تطبيق الآلة الحاسبة على مختلف المنصات.

## 🚀 منصات النشر المدعومة

### 1. Vercel (موصى به)

**المميزات:**
- نشر تلقائي من GitHub
- SSL مجاني
- CDN عالمي
- تكامل سهط مع Next.js

**الخطوات:**

1. **إعداد المستودع**
   ```bash
   git init
   git add .
   git commit -m "Initial commit"
   git remote add origin <your-github-repo>
   git push -u origin main
   ```

2. **النشر على Vercel**
   - اذهب إلى [vercel.com](https://vercel.com)
   - سجل الدخول بحساب GitHub
   - اضغط "New Project"
   - اختر مستودع GitHub
   - أضف متغيرات البيئة:
     ```
     NEXT_PUBLIC_SUPABASE_URL=https://your-project.supabase.co
     NEXT_PUBLIC_SUPABASE_ANON_KEY=your-anon-key
     ```

3. **النشر**
   - اضغط "Deploy"
   - انتظر حتى ينتهي النشر

### 2. Docker

**المميزات:**
- بيئة معزولة
- قابلية التوسع
- سهولة النقل

**الخطوات:**

1. **بناء الصورة**
   ```bash
   docker build -t calculator-app .
   ```

2. **تشغيل الحاوية**
   ```bash
   docker run -p 3000:3000 \
     -e NEXT_PUBLIC_SUPABASE_URL=https://your-project.supabase.co \
     -e NEXT_PUBLIC_SUPABASE_ANON_KEY=your-anon-key \
     calculator-app
   ```

3. **استخدام Docker Compose**
   ```bash
   # إنشاء ملف .env
   cp .env.example .env
   
   # تشغيل
   docker-compose up -d
   ```

### 3. Railway

**المميزات:**
- سهل الاستخدام
- دعم Docker
- نشر من GitHub

**الخطوات:**

1. اذهب إلى [railway.app](https://railway.app)
2. سجل الدخول بحساب GitHub
3. اضغط "New Project"
4. اختر "Deploy from GitHub repo"
5. أضف متغيرات البيئة
6. انشر

### 4. Netlify

**المميزات:**
- نشر سهل
- SSL مجاني
- Forms مجانية

**الخطوات:**

1. اذهب إلى [netlify.com](https://netlify.com)
2. سجل الدخول بحساب GitHub
3. اختر المستودع
4. إعدادات البناء:
   - Build command: `npm run build`
   - Publish directory: `.next`
5. أضف متغيرات البيئة

## 🔧 إعدادات الإنتاج

### متغيرات البيئة

**مطلوبة:**
```env
NEXT_PUBLIC_SUPABASE_URL=https://your-project.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY=your-anon-key
```

**اختيارية:**
```env
NODE_ENV=production
NEXTAUTH_URL=https://your-domain.com
NEXTAUTH_SECRET=your-secret-key
```

### إعدادات Supabase للإنتاج

1. **تفعيل Production Mode**
   - اذهب إلى Settings > General
   - أضف نطاق موقعك في "Site URL"

2. **إعدادات الأمان**
   - فعل "Enable email confirmations" إذا أردت
   - إعدادات "Rate limiting"
   - إعدادات "Custom SMTP" للبريد الإلكتروني

3. **CORS Settings**
   - أضف نطاق موقعك في CORS settings

## 🛡️ الأمان في الإنتاج

### 1. متغيرات البيئة
- لا تضع مفاتيح API في الكود
- استخدم متغيرات البيئة دائماً
- استخدم مفاتيح مختلفة للإنتاج والتطوير

### 2. SSL/HTTPS
- فعل HTTPS دائماً
- استخدم SSL certificates
- إعدادات HSTS

### 3. Rate Limiting
- فعل rate limiting في Supabase
- استخدم Cloudflare للحماية

## 📊 المراقبة والتحليل

### 1. Vercel Analytics
```bash
npm install @vercel/analytics
```

### 2. Supabase Logs
- راقب logs في Supabase Dashboard
- إعدادات alerts

### 3. Error Tracking
```bash
npm install @sentry/nextjs
```

## 🔄 CI/CD

### GitHub Actions

```yaml
name: Deploy to Production

on:
  push:
    branches: [main]

jobs:
  deploy:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v2
      - uses: actions/setup-node@v2
        with:
          node-version: '18'
      - run: npm ci
      - run: npm run build
      - name: Deploy to Vercel
        uses: amondnet/vercel-action@v20
        with:
          vercel-token: ${{ secrets.VERCEL_TOKEN }}
          vercel-org-id: ${{ secrets.ORG_ID }}
          vercel-project-id: ${{ secrets.PROJECT_ID }}
```

## 🚨 استكشاف الأخطاء

### مشاكل شائعة:

1. **Build Errors**
   - تحقق من متغيرات البيئة
   - تأكد من إصدار Node.js

2. **Environment Variables**
   - تحقق من الأسماء الصحيحة
   - تأكد من إضافة NEXT_PUBLIC_ للمتغيرات العامة

3. **Supabase Connection**
   - تحقق من URL و API Keys
   - تأكد من CORS settings

4. **Authentication Issues**
   - تحقق من إعدادات Supabase Auth
   - تأكد من redirect URLs

## 📞 الدعم

إذا واجهت مشاكل في النشر:
1. تحقق من logs
2. راجع هذا الدليل
3. افتح Issue في GitHub
4. تواصل مع فريق الدعم

---

**ملاحظة:** تأكد دائماً من اختبار التطبيق في بيئة staging قبل النشر للإنتاج.