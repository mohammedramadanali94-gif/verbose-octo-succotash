# 🔧 دليل حل مشاكل النشر

## 🚨 **المشاكل الشائعة وحلولها**

### **مشكلة: Page not found / 404**
**السبب:** استخدام منصة لا تدعم Next.js Server-side

**الحل:** استخدم Vercel بدلاً من Netlify/GitHub Pages

---

### **مشكلة: Environment Variables لا تعمل**
**الأعراض:**
- خطأ في الاتصال بـ Supabase
- صفحة بيضاء

**الحل:**
1. تأكد من أسماء المتغيرات:
   ```
   NEXT_PUBLIC_SUPABASE_URL (صحيح)
   SUPABASE_URL (خطأ - يحتاج NEXT_PUBLIC_)
   ```

2. تأكد من القيم الصحيحة:
   ```
   https://uwvfifumomhzroeqvhxa.supabase.co (صحيح)
   https://uwvfifumomhzroeqvhxa.supabase.co/ (خطأ - لا تضع / في النهاية)
   ```

---

### **مشكلة: Build Errors**
**الأعراض:**
- فشل في البناء
- أخطاء TypeScript

**الحل:**
1. تحقق من إصدار Node.js (18 أو أحدث)
2. شغل `npm run build` محلياً أولاً
3. تحقق من ملف `next.config.ts`

---

### **مشكلة: Authentication لا تعمل**
**الأعراض:**
- تسجيل الدخول يفشل
- خطأ في Supabase

**الحل:**
1. تحقق من إعدادات Supabase Auth
2. تأكد من Site URL في Supabase:
   ```
   https://your-app.vercel.app
   ```
3. تحقق من Redirect URLs في Supabase

---

## 🛠️ **أدوات التشخيص**

### **فحص البناء المحلي:**
```bash
npm run build
npm start
```

### **فحص متغيرات البيئة:**
```bash
echo $NEXT_PUBLIC_SUPABASE_URL
```

### **فحص الاتصال بـ Supabase:**
```javascript
// في console المتصفح
const { data } = await supabase.from('users').select('*')
console.log(data)
```

---

## 📋 **قائمة التحقق قبل النشر**

- [ ] الكود يعمل محلياً
- [ ] `npm run build` ينجح بدون أخطاء
- [ ] متغيرات البيئة مضافة بشكل صحيح
- [ ] إعدادات Supabase صحيحة
- [ ] المستودع على GitHub محدث

---

## 🆘 **الحصول على المساعدة**

### **Vercel Support:**
- Build Logs
- Function Logs
- Status Page

### **Supabase Support:**
- Dashboard Logs
- Auth Settings
- CORS Configuration

### **GitHub Issues:**
- افتح issue في المستودع
- صف المشكلة بالتفصيل
- أضف screenshots و logs

---

## 🎯 **أفضل الممارسات**

1. **استخدم Vercel لـ Next.js**
2. **اختبر محلياً قبل النشر**
3. **استخدم متغيرات بيئة منفصلة للإنتاج**
4. **راقب الأداء بعد النشر**
5. **احتفظ بنسخة احتياطية**

---

## 📞 **تواصل معنا**

إذا استمرت المشكلة:
1. راجع هذا الدليل
2. تحقق من logs
3. افتح issue في GitHub
4. تواصل مع فريق الدعم