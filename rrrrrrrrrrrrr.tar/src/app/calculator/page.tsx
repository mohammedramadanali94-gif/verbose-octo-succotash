'use client'

import { useState, useEffect } from 'react'
import { Button } from '@/components/ui/button'
import { Card, CardContent } from '@/components/ui/card'
import { useRouter } from 'next/navigation'
import { supabase } from '@/lib/supabase'

interface User {
  id: string
  email?: string
  user_metadata?: {
    full_name?: string
  }
}

export default function Calculator() {
  const router = useRouter()
  const [display, setDisplay] = useState('0')
  const [previousValue, setPreviousValue] = useState<number | null>(null)
  const [operation, setOperation] = useState<string | null>(null)
  const [waitingForNewValue, setWaitingForNewValue] = useState(false)
  const [user, setUser] = useState<User | null>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    // التحقق من تسجيل الدخول وجلب بيانات المستخدم
    const checkAuth = async () => {
      try {
        const { data: { user }, error } = await supabase.auth.getUser()
        
        if (error || !user) {
          router.push('/')
          return
        }
        
        setUser(user)
      } catch (error) {
        router.push('/')
      } finally {
        setLoading(false)
      }
    }

    checkAuth()

    // الاستماع لتغييرات حالة المصادقة
    const { data: { subscription } } = supabase.auth.onAuthStateChange(
      (event, session) => {
        if (event === 'SIGNED_OUT' || !session?.user) {
          router.push('/')
        } else if (session?.user) {
          setUser(session.user)
        }
      }
    )

    return () => subscription.unsubscribe()
  }, [router])

  const handleLogout = async () => {
    try {
      await supabase.auth.signOut()
      router.push('/')
    } catch (error) {
      console.error('Error signing out:', error)
    }
  }

  const inputNumber = (num: string) => {
    if (waitingForNewValue) {
      setDisplay(num)
      setWaitingForNewValue(false)
    } else {
      setDisplay(display === '0' ? num : display + num)
    }
  }

  const inputDecimal = () => {
    if (waitingForNewValue) {
      setDisplay('0.')
      setWaitingForNewValue(false)
    } else if (display.indexOf('.') === -1) {
      setDisplay(display + '.')
    }
  }

  const clear = () => {
    setDisplay('0')
    setPreviousValue(null)
    setOperation(null)
    setWaitingForNewValue(false)
  }

  const performOperation = (nextOperation: string) => {
    const inputValue = parseFloat(display)

    if (previousValue === null) {
      setPreviousValue(inputValue)
    } else if (operation) {
      const currentValue = previousValue || 0
      const newValue = calculate(currentValue, inputValue, operation)

      setDisplay(String(newValue))
      setPreviousValue(newValue)
    }

    setWaitingForNewValue(true)
    setOperation(nextOperation)
  }

  const calculate = (firstValue: number, secondValue: number, operation: string): number => {
    switch (operation) {
      case '+':
        return firstValue + secondValue
      case '-':
        return firstValue - secondValue
      case '×':
        return firstValue * secondValue
      case '÷':
        return firstValue / secondValue
      case '=':
        return secondValue
      default:
        return secondValue
    }
  }

  const performCalculation = () => {
    const inputValue = parseFloat(display)

    if (previousValue !== null && operation) {
      const newValue = calculate(previousValue, inputValue, operation)
      setDisplay(String(newValue))
      setPreviousValue(null)
      setOperation(null)
      setWaitingForNewValue(true)
    }
  }

  const toggleSign = () => {
    const newValue = parseFloat(display) * -1
    setDisplay(String(newValue))
  }

  const inputPercent = () => {
    const newValue = parseFloat(display) / 100
    setDisplay(String(newValue))
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen bg-gray-50">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto mb-4"></div>
          <p className="text-gray-600">جاري التحميل...</p>
        </div>
      </div>
    )
  }

  const displayName = user?.user_metadata?.full_name || user?.email || 'مستخدم'
  const displayInitial = displayName.charAt(0).toUpperCase()

  return (
    <div className="flex flex-col items-center justify-center min-h-screen bg-gray-50 p-4">
      {/* Header with user info and logout */}
      <div className="w-full max-w-sm mb-6">
        <div className="flex justify-between items-center bg-white p-4 rounded-lg shadow-sm">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 bg-blue-500 rounded-full flex items-center justify-center text-white text-sm font-bold">
              {displayInitial}
            </div>
            <div className="text-right">
              <p className="text-sm font-medium text-gray-900 truncate max-w-[150px]">
                {displayName}
              </p>
              <p className="text-xs text-gray-500 truncate max-w-[150px]">
                {user?.email}
              </p>
            </div>
          </div>
          <Button
            variant="outline"
            size="sm"
            onClick={handleLogout}
            className="text-red-600 hover:text-red-700 hover:bg-red-50"
          >
            تسجيل الخروج
          </Button>
        </div>
      </div>

      <div className="w-full max-w-sm">
        <h1 className="text-3xl font-bold text-center mb-8 text-gray-800">آلة حاسبة</h1>
        
        <Card className="shadow-lg">
          <CardContent className="p-4">
            {/* Display */}
            <div className="bg-gray-900 text-white text-right text-3xl font-mono p-4 rounded mb-4 min-h-[60px] flex items-center justify-end overflow-hidden">
              {display}
            </div>

            {/* Buttons */}
            <div className="grid grid-cols-4 gap-2">
              {/* Row 1 */}
              <Button
                variant="outline"
                onClick={clear}
                className="col-span-2 bg-gray-200 hover:bg-gray-300 text-gray-800 font-semibold"
              >
                مسح
              </Button>
              <Button
                variant="outline"
                onClick={toggleSign}
                className="bg-gray-200 hover:bg-gray-300 text-gray-800 font-semibold"
              >
                +/-
              </Button>
              <Button
                variant="outline"
                onClick={inputPercent}
                className="bg-gray-200 hover:bg-gray-300 text-gray-800 font-semibold"
              >
                %
              </Button>

              {/* Row 2 */}
              <Button
                variant="outline"
                onClick={() => inputNumber('7')}
                className="bg-white hover:bg-gray-100 text-gray-800 text-xl font-semibold"
              >
                ٧
              </Button>
              <Button
                variant="outline"
                onClick={() => inputNumber('8')}
                className="bg-white hover:bg-gray-100 text-gray-800 text-xl font-semibold"
              >
                ٨
              </Button>
              <Button
                variant="outline"
                onClick={() => inputNumber('9')}
                className="bg-white hover:bg-gray-100 text-gray-800 text-xl font-semibold"
              >
                ٩
              </Button>
              <Button
                variant="outline"
                onClick={() => performOperation('÷')}
                className="bg-orange-500 hover:bg-orange-600 text-white text-xl font-semibold"
              >
                ÷
              </Button>

              {/* Row 3 */}
              <Button
                variant="outline"
                onClick={() => inputNumber('4')}
                className="bg-white hover:bg-gray-100 text-gray-800 text-xl font-semibold"
              >
                ٤
              </Button>
              <Button
                variant="outline"
                onClick={() => inputNumber('5')}
                className="bg-white hover:bg-gray-100 text-gray-800 text-xl font-semibold"
              >
                ٥
              </Button>
              <Button
                variant="outline"
                onClick={() => inputNumber('6')}
                className="bg-white hover:bg-gray-100 text-gray-800 text-xl font-semibold"
              >
                ٦
              </Button>
              <Button
                variant="outline"
                onClick={() => performOperation('×')}
                className="bg-orange-500 hover:bg-orange-600 text-white text-xl font-semibold"
              >
                ×
              </Button>

              {/* Row 4 */}
              <Button
                variant="outline"
                onClick={() => inputNumber('1')}
                className="bg-white hover:bg-gray-100 text-gray-800 text-xl font-semibold"
              >
                ١
              </Button>
              <Button
                variant="outline"
                onClick={() => inputNumber('2')}
                className="bg-white hover:bg-gray-100 text-gray-800 text-xl font-semibold"
              >
                ٢
              </Button>
              <Button
                variant="outline"
                onClick={() => inputNumber('3')}
                className="bg-white hover:bg-gray-100 text-gray-800 text-xl font-semibold"
              >
                ٣
              </Button>
              <Button
                variant="outline"
                onClick={() => performOperation('-')}
                className="bg-orange-500 hover:bg-orange-600 text-white text-xl font-semibold"
              >
                −
              </Button>

              {/* Row 5 */}
              <Button
                variant="outline"
                onClick={() => inputNumber('0')}
                className="col-span-2 bg-white hover:bg-gray-100 text-gray-800 text-xl font-semibold"
              >
                ٠
              </Button>
              <Button
                variant="outline"
                onClick={inputDecimal}
                className="bg-white hover:bg-gray-100 text-gray-800 text-xl font-semibold"
              >
                .
              </Button>
              <Button
                variant="outline"
                onClick={() => performOperation('+')}
                className="bg-orange-500 hover:bg-orange-600 text-white text-xl font-semibold"
              >
                +
              </Button>

              {/* Row 6 */}
              <Button
                variant="outline"
                onClick={performCalculation}
                className="col-span-4 bg-green-500 hover:bg-green-600 text-white text-xl font-semibold"
              >
                =
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}