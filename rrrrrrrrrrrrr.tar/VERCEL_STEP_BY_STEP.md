# 📋 دليل النشر على Vercel خطوة بخطوة

## 🎯 **الخطوة 1: الذهاب إلى Vercel**
1. افتح المتصفح واذهب إلى: **https://vercel.com**
2. اضغط على **"Sign Up"** أو **"Login"**

## 🔐 **الخطوة 2: تسجيل الدخول**
1. اختر **"Continue with GitHub"**
2. سجل الدخول بحساب GitHub الخاص بك
3. اضغط **"Authorize Vercel"** لمنح الأذونات

## 📦 **الخطوة 3: استيراد المشروع**
1. في لوحة التحكم، اضغط **"Add New..."**
2. اختر **"Project"**
3. ابحث عن مستودع `calculator-app` في القائمة
4. اضغط **"Import"**

## ⚙️ **الخطوة 4: إعدادات المشروع**
ستظهر صفحة الإعدادات، لا تغير شيئاً في:
- **Framework Preset**: Next.js (سيتم اكتشافه تلقائياً)
- **Root Directory**: اتركه فارغاً
- **Build Command**: `npm run build`
- **Output Directory**: `.next`

## 🔑 **الخطوة 5: إضافة متغيرات البيئة**
1. اذهب إلى قسم **"Environment Variables"**
2. أضف المتغير الأول:
   - **Name**: `NEXT_PUBLIC_SUPABASE_URL`
   - **Value**: `https://uwvfifumomhzroeqvhxa.supabase.co`
   - اضغط **"Add"**

3. أضف المتغير الثاني:
   - **Name**: `NEXT_PUBLIC_SUPABASE_ANON_KEY`
   - **Value**: `eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InV3dmZpZnVtb21oenJvZXF2aHhhIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTk0OTc3OTUsImV4cCI6MjA3NTA3Mzc5NX0.w4LVmWRMNFeFjSrKNGHt08COt2QrdDTeiXmprr_JL5s`
   - اضغط **"Add"**

## 🚀 **الخطوة 6: النشر**
1. اضغط على زر **"Deploy"** الأخضر
2. انتظر 2-3 دقائق حتى ينتهي البناء
3. ستحصل على رابط التطبيق

## ✅ **الخطوة 7: التحقق**
1. اضغط على الرابط الذي ظهر
2. اختبر التطبيق:
   - صفحة تسجيل الدخول تعمل
   - صفحة إنشاء حساب تعمل
   - بعد تسجيل الدخول، تنتقل إلى الحاسبة

## 🎉 **مبارك!**
تطبيقك الآن منشور على Vercel ويعمل بشكل كامل!

## 🔄 **التحديثات المستقبلية**
- أي تغييرات تدفعها إلى GitHub ستنشر تلقائياً
- يمكنك مراقبة النشر في Vercel Dashboard

## 🆘 **إذا واجهت مشاكل:**
1. تحقق من متغيرات البيئة (تأكد من الأسماء الصحيحة)
2. راجع Build Logs في Vercel
3. تأكد من أن الكود مدمج في الفرع الرئيسي (main/master)

---

## 📱 **الرابط النهائي**
سيكون شكل الرابط: `https://your-app-name.vercel.app`

يمكنك تخصيص النطاق لاحقاً في إعدادات المشروع!